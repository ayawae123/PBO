/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pariwisata;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MagelangTentangDAO {

    public void addMagelangTentang(MagelangTentang tentang) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO magelang_tentang (judul, deskripsi, gambar) VALUES (?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, tentang.getJudul());
            ps.setString(2, tentang.getDeskripsi());
            ps.setString(3, tentang.getGambar());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public MagelangTentang getMagelangTentang(String judul) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM magelang_tentang WHERE judul = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, judul);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                MagelangTentang tentang = new MagelangTentang();
                tentang.setJudul(rs.getString("judul"));
                tentang.setDeskripsi(rs.getString("deskripsi"));
                tentang.setGambar(rs.getString("gambar"));
                return tentang;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<MagelangTentang> getAllMagelangTentang() {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM magelang_tentang";
        List<MagelangTentang> listTentang = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MagelangTentang tentang = new MagelangTentang();
                tentang.setJudul(rs.getString("judul"));
                tentang.setDeskripsi(rs.getString("deskripsi"));
                tentang.setGambar(rs.getString("gambar"));
                listTentang.add(tentang);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listTentang;
    }

    public void updateMagelangTentang(MagelangTentang tentang) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "UPDATE magelang_tentang SET deskripsi = ?, gambar = ? WHERE judul = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, tentang.getDeskripsi());
            ps.setString(2, tentang.getGambar());
            ps.setString(3, tentang.getJudul());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMagelangTentang(String judul) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM magelang_tentang WHERE judul = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, judul);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


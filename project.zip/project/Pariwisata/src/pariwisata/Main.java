/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pariwisata;
public class Main {
    public static void main(String[] args) {
        // Contoh penggunaan kelas DAO untuk MagelangWisata
        MagelangWisataDAO wisataDAO = new MagelangWisataDAO();
        MagelangWisata wisata = new MagelangWisata();
        wisata.setIdWisata(1);
        wisata.setIdDaerah(1);
        wisata.setIdKategori(1);
        wisata.setNamaWisata("Candi Borobudur");
        wisata.setDeskripsi("Candi Buddha terbesar di dunia.");
        wisata.setGambar("gambar.jpg");
        wisata.setLongitude(110.203545);
        wisata.setLatitude(-7.607875);
        wisata.setGambar2("gambar2.jpg");
        wisata.setGambar3("gambar3.jpg");
        wisata.setGambar4("gambar4.jpg");
        wisata.setGambar5("gambar5.jpg");
        wisataDAO.addMagelangWisata(wisata);

        MagelangWisata retrievedWisata = wisataDAO.getMagelangWisata(1);
        System.out.println("Nama Wisata: " + retrievedWisata.getNamaWisata());

        retrievedWisata.setNamaWisata("Candi Borobudur Updated");
        wisataDAO.updateMagelangWisata(retrievedWisata);

        wisataDAO.deleteMagelangWisata(1);

        // Contoh penggunaan kelas DAO untuk MagelangTentang
        MagelangTentangDAO tentangDAO = new MagelangTentangDAO();
        MagelangTentang tentang = new MagelangTentang();
        tentang.setJudul("Sejarah Borobudur");
        tentang.setDeskripsi("Sejarah pembangunan Candi Borobudur.");
        tentang.setGambar("sejarah.jpg");
        tentangDAO.addMagelangTentang(tentang);

        MagelangTentang retrievedTentang = tentangDAO.getMagelangTentang("Sejarah Borobudur");
        System.out.println("Judul: " + retrievedTentang.getJudul());

        retrievedTentang.setDeskripsi("Sejarah lengkap pembangunan Candi Borobudur.");
        tentangDAO.updateMagelangTentang(retrievedTentang);

        tentangDAO.deleteMagelangTentang("Sejarah Borobudur");

        // Contoh penggunaan kelas DAO untuk Uji
        UjiDAO ujiDAO = new UjiDAO();
        Uji uji = new Uji();
        uji.setNik("1234567890");
        uji.setNama("Mariyani");
        uji.setTelpon("08123456789");
        uji.setAlamat("Magelang");
        ujiDAO.addUji(uji);

        Uji retrievedUji = ujiDAO.getUji("1234567890");
        System.out.println("Nama: " + retrievedUji.getNama());

        retrievedUji.setNama("Mariyani Updated");
        ujiDAO.updateUji(retrievedUji);

        ujiDAO.deleteUji("1234567890");
    }
}

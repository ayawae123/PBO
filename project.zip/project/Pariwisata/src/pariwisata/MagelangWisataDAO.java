/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pariwisata;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MagelangWisataDAO {

    public void addMagelangWisata(MagelangWisata wisata) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO magelang_wisata (id_wisata, id_daerah, id_kategori, nama_wisata, deskripsi, gambar, longitude, latitude, gambar2, gambar3, gambar4, gambar5) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, wisata.getIdWisata());
            ps.setInt(2, wisata.getIdDaerah());
            ps.setInt(3, wisata.getIdKategori());
            ps.setString(4, wisata.getNamaWisata());
            ps.setString(5, wisata.getDeskripsi());
            ps.setString(6, wisata.getGambar());
            ps.setDouble(7, wisata.getLongitude());
            ps.setDouble(8, wisata.getLatitude());
            ps.setString(9, wisata.getGambar2());
            ps.setString(10, wisata.getGambar3());
            ps.setString(11, wisata.getGambar4());
            ps.setString(12, wisata.getGambar5());
            ps.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public MagelangWisata getMagelangWisata(int id) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM magelang_wisata WHERE id_wisata = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                MagelangWisata wisata = new MagelangWisata();
                wisata.setIdWisata(rs.getInt("id_wisata"));
                wisata.setIdDaerah(rs.getInt("id_daerah"));
                wisata.setIdKategori(rs.getInt("id_kategori"));
                wisata.setNamaWisata(rs.getString("nama_wisata"));
                wisata.setDeskripsi(rs.getString("deskripsi"));
                wisata.setGambar(rs.getString("gambar"));
                wisata.setLongitude(rs.getDouble("longitude"));
                wisata.setLatitude(rs.getDouble("latitude"));
                wisata.setGambar2(rs.getString("gambar2"));
                wisata.setGambar3(rs.getString("gambar3"));
                wisata.setGambar4(rs.getString("gambar4"));
                wisata.setGambar5(rs.getString("gambar5"));
                return wisata;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<MagelangWisata> getAllMagelangWisata() {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM magelang_wisata";
        List<MagelangWisata> listWisata = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MagelangWisata wisata = new MagelangWisata();
                wisata.setIdWisata(rs.getInt("id_wisata"));
                wisata.setIdDaerah(rs.getInt("id_daerah"));
                wisata.setIdKategori(rs.getInt("id_kategori"));
                wisata.setNamaWisata(rs.getString("nama_wisata"));
                wisata.setDeskripsi(rs.getString("deskripsi"));
                wisata.setGambar(rs.getString("gambar"));
                wisata.setLongitude(rs.getDouble("longitude"));
                wisata.setLatitude(rs.getDouble("latitude"));
                wisata.setGambar2(rs.getString("gambar2"));
                wisata.setGambar3(rs.getString("gambar3"));
                wisata.setGambar4(rs.getString("gambar4"));
                wisata.setGambar5(rs.getString("gambar5"));
                listWisata.add(wisata);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listWisata;
    }

    public void updateMagelangWisata(MagelangWisata wisata) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "UPDATE magelang_wisata SET id_daerah = ?, id_kategori = ?, nama_wisata = ?, deskripsi = ?, gambar = ?, longitude = ?, latitude = ?, gambar2 = ?, gambar3 = ?, gambar4 = ?, gambar5 = ? WHERE id_wisata = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, wisata.getIdDaerah());
            ps.setInt(2, wisata.getIdKategori());
            ps.setString(3, wisata.getNamaWisata());
            ps.setString(4, wisata.getDeskripsi());
            ps.setString(5, wisata.getGambar());
            ps.setDouble(6, wisata.getLongitude());
            ps.setDouble(7, wisata.getLatitude());
            ps.setString(8, wisata.getGambar2());
            ps.setString(9, wisata.getGambar3());
            ps.setString(10, wisata.getGambar4());
            ps.setString(11, wisata.getGambar5());
            ps.setInt(12, wisata.getIdWisata());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMagelangWisata(int id) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM magelang_wisata WHERE id_wisata = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pariwisata;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UjiDAO {

    public void addUji(Uji uji) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "INSERT INTO uji (nik, nama, telpon, alamat) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, uji.getNik());
            ps.setString(2, uji.getNama());
            ps.setString(3, uji.getTelpon());
            ps.setString(4, uji.getAlamat());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Uji getUji(String nik) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM uji WHERE nik = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, nik);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Uji uji = new Uji();
                uji.setNik(rs.getString("nik"));
                uji.setNama(rs.getString("nama"));
                uji.setTelpon(rs.getString("telpon"));
                uji.setAlamat(rs.getString("alamat"));
                return uji;
            }
        } catch (SQLException e) {
        }
        return null;
    }

    public List<Uji> getAllUji() {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM uji";
        List<Uji> listUji = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Uji uji = new Uji();
                uji.setNik(rs.getString("nik"));
                uji.setNama(rs.getString("nama"));
                uji.setTelpon(rs.getString("telpon"));
                uji.setAlamat(rs.getString("alamat"));
                listUji.add(uji);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listUji;
    }

    public void updateUji(Uji uji) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "UPDATE uji SET nama = ?, telpon = ?, alamat = ? WHERE nik = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, uji.getNama());
            ps.setString(2, uji.getTelpon());
            ps.setString(3, uji.getAlamat());
            ps.setString(4, uji.getNik());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteUji(String nik) {
        Connection connection = DatabaseConnection.getConnection();
        String sql = "DELETE FROM uji WHERE nik = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, nik);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
